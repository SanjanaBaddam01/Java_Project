
import java.util.Scanner;

public class ExceptionHandlingDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Getting input from the user
            System.out.print("Enter numerator: ");
            int numerator = scanner.nextInt();

            System.out.print("Enter denominator: ");
            int denominator = scanner.nextInt();

            // Division operation that may throw ArithmeticException
            int result = divide(numerator, denominator);

            // Printing the result if division is successful
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Handling ArithmeticException
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            // Handling other exceptions
            System.out.println("Error: " + e.getMessage());
        } finally {
            // Closing resources or performing cleanup
            System.out.println("Finally block executed.");
            scanner.close();
        }

        System.out.println("Program continues...");
    }

    // Method that may throw ArithmeticException
    private static int divide(int numerator, int denominator) {
        if (denominator == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return numerator / denominator;
    }
}
