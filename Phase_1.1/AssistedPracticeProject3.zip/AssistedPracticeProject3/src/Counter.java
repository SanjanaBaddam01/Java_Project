
class Counter {
    private int count = 0;

    // Synchronized method
    public synchronized void increment() {
        count++;
    }

    // Synchronized method
    public synchronized int getCount() {
        return count;
    }
}
