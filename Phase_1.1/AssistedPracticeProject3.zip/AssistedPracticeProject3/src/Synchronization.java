
public class Synchronization{
    public static void main(String[] args) throws InterruptedException {
        Counter counter = new Counter();

        IncrementThread t1 = new IncrementThread(counter);
        IncrementThread t2 = new IncrementThread(counter);

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        // Both threads increment the counter 1000 times, so the expected count is 2000
        System.out.println("Final Count: " + counter.getCount());
    }
}
