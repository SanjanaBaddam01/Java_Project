
public class ThreadExample1 {
    public static void main(String args[]) {
        MyThread t1 = new MyThread();
        t1.start(); // Start the thread

        MyThread t2 = new MyThread();
        t2.start(); // Start another thread
    }
}
