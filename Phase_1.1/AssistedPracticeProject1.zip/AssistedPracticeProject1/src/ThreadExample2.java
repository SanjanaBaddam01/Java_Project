
public class ThreadExample2 {
    public static void main(String args[]) {
        Thread t1 = new Thread(new MyRunnable());
        t1.start(); // Start the thread

        Thread t2 = new Thread(new MyRunnable());
        t2.start(); // Start another thread
    }
}
