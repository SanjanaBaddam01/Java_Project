
public class DiamondProblem {
    public static void main(String[] args) {
        Platypus platypus = new Platypus();

        // Calling methods from both Mammal and Bird interfaces
        platypus.makeSound();
        platypus.giveBirth();
        platypus.layEggs();
    }
}