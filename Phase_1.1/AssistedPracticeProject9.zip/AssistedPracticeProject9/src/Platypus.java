
interface Animal {
    void makeSound();
}

// Interfaces inheriting from the common interface
interface Mammal extends Animal {
    void giveBirth();
}

interface Bird extends Animal {
    void layEggs();
}

// Concrete class implementing both Mammal and Bird interfaces
class Platypus implements Mammal, Bird {
    @Override
    public void makeSound() {
        System.out.println("Platypus makes a unique sound.");
    }

    @Override
    public void giveBirth() {
        System.out.println("Platypus gives birth to live young.");
    }

    @Override
    public void layEggs() {
        System.out.println("Platypus lays eggs.");
    }
}