
class NumberPrinter extends Thread {
    SharedResource resource;

    public NumberPrinter(SharedResource resource) {
        this.resource = resource;
    }

    public void run() {
        resource.printNumbers();
    }
}
