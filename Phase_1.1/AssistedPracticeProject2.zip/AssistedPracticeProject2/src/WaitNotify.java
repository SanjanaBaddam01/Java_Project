
public class WaitNotify {
    public static void main(String[] args) {
        SharedResource sharedResource = new SharedResource();
        
        Thread t1 = new NumberPrinter(sharedResource);
        Thread t2 = new NumberPrinter(sharedResource);

        t1.start();
        t2.start();
    }
}
