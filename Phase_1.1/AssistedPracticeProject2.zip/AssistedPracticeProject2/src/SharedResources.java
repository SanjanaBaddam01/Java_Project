
class SharedResource {
    boolean flag = false;

    synchronized void printNumbers() {
        for (int i = 1; i <= 5; i++) {
            while (flag) {
                try {
                    wait(); // Release the lock and wait for notify
                } catch (InterruptedException e) {
                    System.out.println(e.getMessage());
                }
            }
            System.out.println(Thread.currentThread().getName() + ": " + i);
            flag = true;
            notify(); // Notify waiting thread (if any)
        }
    }
}

