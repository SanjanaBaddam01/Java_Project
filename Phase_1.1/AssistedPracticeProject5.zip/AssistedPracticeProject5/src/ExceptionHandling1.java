
public class ExceptionHandling1 {
    // Method that throws an exception using 'throws'
    public static void methodWithThrows(int number) throws CustomException {
        if (number <= 0) {
            throw new CustomException("Number must be greater than 0");
        }
        System.out.println("Number is: " + number);
      }

    // Method that throws an exception using 'throw'
    public static void methodWithThrow(int divisor) {
        try {
            if (divisor == 0) {
                throw new ArithmeticException("Cannot divide by zero");
            }
            int result = 10 / divisor;
            System.out.println("Result is: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            System.out.println("Finally block in methodWithThrow");
        }
    }

    public static void main(String[] args) {
        try {
            // Calling a method that throws an exception using 'throws'
            methodWithThrows(0);
        } catch (CustomException e) {
            System.out.println("Caught CustomException: " + e.getMessage());
        } finally {
            System.out.println("Finally block in main method");
        }

        try {
            // Calling a method that throws an exception using 'throw'
            methodWithThrow(0);
        } finally {
            System.out.println("Finally block in main method after methodWithThrow");
        }
    }
}
