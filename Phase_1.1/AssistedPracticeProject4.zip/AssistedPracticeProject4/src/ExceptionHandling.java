
import java.util.Scanner;

public class ExceptionHandling {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Get input from the user
            System.out.print("Enter a number: ");
            int number = scanner.nextInt();

            // Perform a division operation
            int result = 10 / number;

            // This line will not be executed if an exception occurs
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Catch block for ArithmeticException
            System.out.println("Error: Division by zero is not allowed.");
        } catch (Exception e) {
            // Catch block for other exceptions
            System.out.println("Error: " + e.getMessage());
        } finally {
            // Finally block will be executed whether an exception occurs or not
            System.out.println("Finally block executed.");
            scanner.close(); // Close the scanner in the finally block
        }

        System.out.println("Program continues...");
    }
}
