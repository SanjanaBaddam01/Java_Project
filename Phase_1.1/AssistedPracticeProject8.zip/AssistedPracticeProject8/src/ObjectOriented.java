
public class ObjectOriented {
    public static void main(String[] args) {
        // Creating objects
        Shape shape = new Shape("Red");
        Circle circle = new Circle("Blue", 5.0);

        // Using methods and properties
        shape.displayInfo();
        circle.displayInfo();

        // Using polymorphism
        Shape polymorphicShape = new Circle("Green", 8.0);
        polymorphicShape.displayInfo();

        // Using inheritance and subclass-specific method
        System.out.println("Circle area: " + ((Circle) polymorphicShape).calculateArea());
    }
}
