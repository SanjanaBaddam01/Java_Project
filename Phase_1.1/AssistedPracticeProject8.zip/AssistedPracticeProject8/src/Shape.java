
class Shape {
    // Fields
    private String color;

    // Constructor
    public Shape(String color) {
        this.color = color;
    }

    // Getter and setter methods for encapsulation
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    // Method for abstraction
    public void displayInfo() {
        System.out.println("This is a shape with color: " + color);
    }
}
