
class Circle extends Shape {
    private double radius;

    // Constructor
    public Circle(String color, double radius) {
        super(color); // Call the constructor of the superclass (Shape)
        this.radius = radius;
    }

    // Method for polymorphism
    @Override
    public void displayInfo() {
        System.out.println("This is a circle with color: " + getColor() + " and radius: " + radius);
    }

    // Additional method specific to Circle
    public double calculateArea() {
        return Math.PI * radius * radius;
    }
}
